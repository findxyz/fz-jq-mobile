<?php
$type = 'text/css';
$files = array(
	'../../../LICENSE-INFO.txt',
	'jquery.mobile.theme.css'
);
$base = dirname(__FILE__);
require_once('../../structure/index.php');
